<blockquote class="item-testimonial">
	<?php the_content(); ?>

	<?php the_post_thumbnail( 'milos-menu-item' ); ?>

	<cite><?php the_title(); ?></cite>
</blockquote>
